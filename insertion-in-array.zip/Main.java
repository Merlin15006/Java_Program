//insertion in array
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n+1];
      
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
           
        }
        int pos=sc.nextInt();
        if(pos<0||pos>n+1){
            System.out.println("Invalid");
        }
        else{
            int e=sc.nextInt();
            for(int i=n;i>pos;i--){
                arr[i]=arr[i-1];
                
            }
            arr[pos]=e;
        }
        for(int x:arr){
              System.out.println(x+" ");
        }
        
    }
}
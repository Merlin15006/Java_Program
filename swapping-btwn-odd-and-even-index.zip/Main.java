import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
      
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
           
        }
       
        
            for(int i=0;i<n-2;i=i+4){
                   int temp=arr[i];
                   arr[i]=arr[i+2];
                   arr[i+2]=temp;
                }
                
            for(int i=1;i<n-2;i=i+4){
                   int temp=arr[i];
                   arr[i]=arr[i+2];
                   arr[i+2]=temp;
                }
            
            for(int x:arr){
            
              System.out.print(x+" ");
        }
        
           
        }
}
        
        

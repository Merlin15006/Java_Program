import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int s=sc.nextInt();
        int ans=0;
        int c=0;
        while(n>0){
            int r=n%10;
            if (s!=r){
                c++;
                ans=r*(int)(Math.pow(10,c-1))+ans;
            } 
            n=n/10;
        }
        System.out.println(ans);
    }
}mv 
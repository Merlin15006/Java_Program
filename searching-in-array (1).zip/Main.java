//searching in array
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
      
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
           
        }
        int search=sc.nextInt();
        
            for(int i=0;i<n;i++){
                if(arr[i]==search){
                    System.out.println(i);
                    return;
                }
                
            }
            
              System.out.print("-1");
        }
        
           
        }
        
        

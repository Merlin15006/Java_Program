import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int n=num;
        int a =num;
        int sum=0;
        int c = 0;

        while (num>0) {
            int digit = num % 10;    
            c++; 
            num = num / 10;         
        }
        while(n>0){
            int d=n%10;
            sum+=Math.pow(d,c);
            n=n/10;
        }
        System.out.println(sum);
        if(a==sum){
            System.out.println("Armstrong");
        }
        else{
            System.out.println("Not an Armstrong");
        }
        
    }
    
}
